package edu.jhu.cs.gyifan1.oose;

/**
 * Listener for piece selection change events.
 * 
 * @author yifan
 *
 */
public interface MyBrickusPieceSelectionChangeListener {
	public void pieceSelectionChanged(MyBrickusPieceSelectionModel selectionModel);
}
