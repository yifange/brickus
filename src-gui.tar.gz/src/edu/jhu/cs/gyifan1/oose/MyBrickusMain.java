package edu.jhu.cs.gyifan1.oose;
/**
 * 
 * @author yifan
 * 
 * Main entry of the program.
 */
public class MyBrickusMain {

	/**
	 * @param args
	 *          The arguments passed to main.
	 */
	public static void main(String[] args) {
		MyBrickusFrame gui = new MyBrickusFrame();
		gui.setLocationRelativeTo(null);
		gui.setVisible(true);
	}
}
